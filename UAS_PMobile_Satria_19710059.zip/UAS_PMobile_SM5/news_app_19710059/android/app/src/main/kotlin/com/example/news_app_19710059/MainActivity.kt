package com.example.news_app_19710059

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
